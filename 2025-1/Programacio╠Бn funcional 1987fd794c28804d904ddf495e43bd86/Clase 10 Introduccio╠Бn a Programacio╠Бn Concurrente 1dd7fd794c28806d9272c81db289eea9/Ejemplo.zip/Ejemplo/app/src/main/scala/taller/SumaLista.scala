package taller
import common._

import scala.annotation.tailrec

class SumaLista {

  @tailrec
  final def sumarListaA(l:Array[Int], a:Int, b:Int, acc:Int=0) :Int = {
    if (a > b) acc
    else sumarListaA(l, a+1, b, acc + l(a))
  }

}
