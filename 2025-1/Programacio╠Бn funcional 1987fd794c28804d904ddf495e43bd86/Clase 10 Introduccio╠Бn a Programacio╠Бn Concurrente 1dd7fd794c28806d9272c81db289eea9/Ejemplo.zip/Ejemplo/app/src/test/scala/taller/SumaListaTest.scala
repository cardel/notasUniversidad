package taller

import org.junit.runner.RunWith
import org.scalatest.funsuite.AnyFunSuiteLike
import org.scalatestplus.junit.JUnitRunner
import common._

@RunWith(classOf[JUnitRunner])
class SumaListaTest extends AnyFunSuiteLike {
  val objSumaLista = new SumaLista()

  test("Suma parcial de los primeros 10 elementos") {
    val expected = 55
    val l = (0 to 100000).toArray
    val current = objSumaLista.sumarListaA(l, 0, 10)
    assert(expected == current)
  }

  test("Suma todos lo snumeros") {
    val expected = 100000 * (100001) / 2
    val l = (0 to 100000).toArray
    val current = objSumaLista.sumarListaA(l, 0, 100000)
    assert(expected == current)
  }

  //Trabajar la paralizacion 2 hilos
  test("Suma con dos hilos") {
    val l = (0 to 100000).toArray
    val mitad = l.length/2
    val (r1,r2) = parallel(
      objSumaLista.sumarListaA(l, 0, mitad),
      objSumaLista.sumarListaA(l, mitad+1, l.length-1)
    )
    val expected = 100000*100001/2
    assert(expected == (r1+r2))
  }

  //Trabajar la paralelizacion en 4 hilos
  test("Paralelizacion 4 hilos") {
    val l = (0 to 100000).toArray
    val expected = 100000*100001/2
    val (r1,r2,r3,r4) = parallel(
      objSumaLista.sumarListaA(l, 0, l.length/4),
      objSumaLista.sumarListaA(l, l.length/4+1, l.length/2),
      objSumaLista.sumarListaA(l, l.length/2+1, 3*l.length/4),
      objSumaLista.sumarListaA(l, 3*l.length/4+1, l.length-1)
    )
    assert(expected == r1+r2+r3+r4)
  }

  //Trabajar la paralelizacion en 9 hilos
  test("Paralelizacion 8 hilos") {
    val l = (0 to 100000).toArray
    val expected = 100000*100001/2
    val (r1,r2,r3,r4) = parallel(
      objSumaLista.sumarListaA(l, 0, l.length/8),
      objSumaLista.sumarListaA(l, l.length/8+1, l.length/4),
      objSumaLista.sumarListaA(l, l.length/4+1, 3*l.length/8),
      objSumaLista.sumarListaA(l, 3*l.length/8+1, l.length/2)
    )
    val (r5,r6,r7,r8) = parallel(
      objSumaLista.sumarListaA(l,  l.length/2+1, 5*l.length/8),
      objSumaLista.sumarListaA(l, 5*l.length/8+1, 6*l.length/8),
      objSumaLista.sumarListaA(l, 6*l.length/8+1, 7*l.length/8),
      objSumaLista.sumarListaA(l, 7*l.length/8+1, l.length-1)
    )
    assert(expected == r1+r2+r3+r4+r5+r6+r7+r8)
  }

  //lanzar 6 hilos con task
  test("6 hilos con task") {
    val l = (0 to 100000).toArray
    val expected = 100000*100001/2
    val t1 = task(objSumaLista.sumarListaA(l, 0, l.length/6))
    val t2 = task(objSumaLista.sumarListaA(l, l.length/6+1, l.length/3))
    val t3 = task(objSumaLista.sumarListaA(l, l.length/3+1, 3*l.length/6))
    val t4 = task(objSumaLista.sumarListaA(l, 3*l.length/6+1, 4*l.length/6))
    val t5 = task(objSumaLista.sumarListaA(l, 4*l.length/6+1, 5*l.length/6))
    val t6 = task(objSumaLista.sumarListaA(l, 5*l.length/6+1, l.length-1))
    val r1 = t1.join()
    val r2 = t2.join()
    val r3 = t3.join()
    val r4 = t4.join()
    val r5 = t5.join()
    val r6 = t6.join()
    assert(expected == r1+r2+r3+r4+r5+r6)

  }
}
