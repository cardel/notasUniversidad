# Plantilla talleres programación funcional

## Reglas

- Sólo modificar lo indicado por el docente
- Debe agregar las pruebas de software solicitadas en el docente
- El informe en formato PDF debe estar en la raiz del proyecto
