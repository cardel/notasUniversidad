#!/bin/bash

kubectl apply -f mysql-service.yaml
kubectl apply -f mysql-statefulset.yaml
kubectl apply -f app-service.yaml
kubectl apply -f app-deployment.yaml
kubectl apply -f nginx-config.yaml
kubectl apply -f nginx-deployment.yaml
kubectl apply -f nginx-service.yaml
